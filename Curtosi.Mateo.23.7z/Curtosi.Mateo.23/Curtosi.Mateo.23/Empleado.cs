﻿namespace Curtosi.Mateo._23
{
    public class Class1
    {
       
    }
}
