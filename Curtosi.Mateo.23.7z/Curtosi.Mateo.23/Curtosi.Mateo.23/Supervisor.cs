﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Curtosi.Mateo._23
{
    internal class Supervisor
    {
    }
}
